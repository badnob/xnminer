"""
account.py - Account service.

Async account management backed by StorageManager's AccountRepo.
Provides the same logical interface for the rest of the server.
"""

import logging
from typing import TYPE_CHECKING, Dict, Optional

if TYPE_CHECKING:
    from server.storage import AccountRepo

logger = logging.getLogger("account")


class AccountService:
    """Account service backed by SQLite via AccountRepo."""

    def __init__(self, repo: "AccountRepo"):
        self._repo = repo

    async def setup_defaults(self):
        """Create default test accounts if they don't exist."""
        await self.create_account("consumer-1", "consumer", balance=1000.0,
                                  eth_address="0xaabbccddee1234567890abcdef1234567890abcd")
        await self.create_account("consumer-2", "consumer", balance=500.0,
                                  eth_address="0x1111111111222222222233333333334444444444")

    async def create_account(
        self, account_id: str, role: str,
        balance: float = 0.0, eth_address: str = ""
    ) -> dict:
        """Create a new account or return existing one."""
        acct = await self._repo.create(account_id, role, balance=balance, eth_address=eth_address)
        if acct:
            logger.info("Created/found account %s role=%s balance=%.4f", account_id, role, acct["balance"])
        return acct

    async def get_account(self, account_id: str) -> Optional[dict]:
        """Retrieve an account by ID, or None if not found."""
        return await self._repo.get(account_id)

    async def get_or_create_provider(self, worker_id: str, eth_address: str) -> dict:
        """Get an existing provider account or create one for the given worker."""
        return await self._repo.get_or_create_provider(worker_id, eth_address)

    async def get_or_create_by_eth_address(self, address: str) -> dict:
        """Get or create an account by Ethereum wallet address."""
        acct = await self._repo.get_by_eth_address(address)
        if acct is not None:
            return acct
        account_id = f"wallet-{address[:10].lower()}"
        acct = await self._repo.create(account_id, "provider", eth_address=address)
        if acct:
            logger.info("Created wallet account %s for %s", account_id, address)
        return acct

    async def deposit(self, account_id: str, amount: float) -> dict:
        """Deposit funds into an account."""
        return await self._repo.deposit(account_id, amount)

    async def withdraw(self, account_id: str, amount: float) -> dict:
        return await self._repo.withdraw(account_id, amount)

    async def transfer(self, from_id: str, to_id: str, amount: float):
        """Transfer funds between two accounts."""
        await self._repo.transfer(from_id, to_id, amount)

    async def list_accounts(self) -> Dict[str, dict]:
        """Return all accounts as a dict keyed by account_id."""
        return await self._repo.list_all()
