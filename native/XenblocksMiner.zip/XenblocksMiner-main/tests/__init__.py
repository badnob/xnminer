"""XenblocksMiner test suite."""
